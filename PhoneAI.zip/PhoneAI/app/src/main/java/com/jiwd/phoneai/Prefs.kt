package com.jiwd.phoneai

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray

object Prefs {
    private val sp: SharedPreferences
        get() = App.instance.getSharedPreferences("phoneai", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("key", "") ?: ""
        set(v) = sp.edit().putString("key", v.trim()).apply()

    var model: String
        get() = sp.getString("model", "claude-sonnet-5-5") ?: "claude-sonnet-5-5"
        set(v) = sp.edit().putString("model", v.trim()).apply()

    var confirmSensitive: Boolean
        get() = sp.getBoolean("confirm", true)
        set(v) = sp.edit().putBoolean("confirm", v).apply()

    var speak: Boolean
        get() = sp.getBoolean("speak", false)
        set(v) = sp.edit().putBoolean("speak", v).apply()

    // Saved shortcuts (long-press one of your messages to save it)
    val routines = MutableStateFlow(loadRoutines())

    private fun loadRoutines(): List<String> = try {
        val a = JSONArray(sp.getString("routines", "[]"))
        List(a.length()) { a.getString(it) }
    } catch (e: Exception) {
        emptyList()
    }

    private fun saveRoutines(list: List<String>) {
        routines.value = list
        sp.edit().putString("routines", JSONArray(list).toString()).apply()
    }

    fun addRoutine(text: String) {
        val t = text.trim()
        if (t.isBlank() || t in routines.value || routines.value.size >= 12) return
        saveRoutines(routines.value + t)
    }

    fun removeRoutine(text: String) {
        saveRoutines(routines.value - text)
    }
}
